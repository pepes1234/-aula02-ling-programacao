#include <stdio.h>
#include <ctype.h>

int main() {
    // declaracoes de variaveis
    float peso, altura, imc;
    int idade;
    char sexo;

    // leitura e validacao do peso
    printf("Digite o peso (kg): ");
    while (scanf("%f", &peso) != 1 || peso <= 0) {
        printf("Peso invalido, digite novamente: ");
        while (getchar() != '\n');
    }

    // leitura e validacao da altura
    printf("Digite a altura (m): ");
    while (scanf("%f", &altura) != 1 || altura <= 0) {
        printf("Altura invalida, digite novamente: ");
        while (getchar() != '\n');
    }

    // leitura e validacao da idade
    printf("Digite a idade (anos): ");
    while (scanf("%d", &idade) != 1 || idade <= 0) {
        printf("Idade invalida, digite novamente: ");
        while (getchar() != '\n');
    }

    // leitura e validacao do sexo
    printf("Digite o sexo (M/F): ");
    while (scanf(" %c", &sexo) != 1 || (tolower(sexo) != 'm' && tolower(sexo) != 'f')) {
        printf("Sexo invalido, digite M ou F: ");
        while (getchar() != '\n');
    }
    sexo = tolower(sexo);

    // calculo do imc
    imc = peso / (altura * altura);

    // classificacao do imc
    printf("IMC: %.2f\n", imc);
    if (imc < 18.5) {
        printf("Classificacao: abaixo do peso\n");
    } else if (imc < 25.0) {
        printf("Classificacao: peso normal\n");
    } else if (imc < 30.0) {
        printf("Classificacao: sobrepeso\n");
    } else if (imc < 35.0) {
        printf("Classificacao: obesidade grau I\n");
    } else if (imc < 40.0) {
        printf("Classificacao: obesidade grau II\n");
    } else {
        printf("Classificacao: obesidade grau III\n");
    }

    // recomendacoes personalizadas
    if (imc < 18.5 && idade >= 60) {
        printf("Recomendacao: consultar geriatra\n");
    }
    if (imc >= 25.0 && sexo == 'm') {
        printf("Recomendacao: praticar exercicios de forca\n");
    }
    if (imc >= 25.0 && sexo == 'f') {
        printf("Recomendacao: praticar exercicios aerobicos\n");
    }
    if (imc >= 30.0 && idade <= 25) {
        printf("Recomendacao: procurar nutricionista\n");
    }

    return 0;
}