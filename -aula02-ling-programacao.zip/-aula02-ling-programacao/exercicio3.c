#include <stdio.h>

// funcao para mostrar o menu
void mostrar_menu() {
    printf("\n=== Caixa Eletronico ===\n");
    printf("1 - Consultar saldo\n");
    printf("2 - Depositar\n");
    printf("3 - Sacar\n");
    printf("4 - Transferir\n");
    printf("5 - Sair\n");
    printf("Escolha uma opcao: ");
}

// funcao para consultar saldo
void consultar_saldo(float saldo) {
    printf("Saldo atual: R$ %.2f\n", saldo);
}

// funcao para depositar
void depositar(float *saldo) {
    float valor;
    printf("Digite o valor para deposito: R$ ");
    scanf("%f", &valor);
    if (valor >= 0.01) {
        *saldo += valor;
        printf("Deposito realizado com sucesso!\n");
    } else {
        printf("Valor invalido para deposito.\n");
    }
    consultar_saldo(*saldo);
}

// funcao para sacar
void sacar(float *saldo) {
    float valor;
    printf("Digite o valor para saque: R$ ");
    scanf("%f", &valor);
    if (valor > 500.00) {
        printf("Valor maximo para saque por operacao e R$ 500,00.\n");
    } else if (valor <= 0) {
        printf("Valor invalido para saque.\n");
    } else if (valor > *saldo) {
        printf("Saldo insuficiente para saque.\n");
    } else {
        *saldo -= valor;
        printf("Saque realizado com sucesso!\n");
    }
    consultar_saldo(*saldo);
}

// funcao para transferir
void transferir(float *saldo) {
    float valor, taxa;
    printf("Digite o valor para transferencia: R$ ");
    scanf("%f", &valor);
    if (valor <= 0) {
        printf("Valor invalido para transferencia.\n");
        consultar_saldo(*saldo);
        return;
    }
    taxa = valor * 0.01;
    if (taxa < 2.00) {
        taxa = 2.00;
    }
    if (valor + taxa > *saldo) {
        printf("Saldo insuficiente para transferencia (incluindo taxa).\n");
    } else {
        *saldo -= (valor + taxa);
        printf("Transferencia realizada com sucesso!\n");
        printf("Taxa cobrada: R$ %.2f\n", taxa);
    }
    consultar_saldo(*saldo);
}

int main() {
    float saldo = 1000.00;
    int opcao;
    do {
        mostrar_menu();
        scanf("%d", &opcao);
        switch(opcao) {
            case 1:
                consultar_saldo(saldo);
                break;
            case 2:
                depositar(&saldo);
                break;
            case 3:
                sacar(&saldo);
                break;
            case 4:
                transferir(&saldo);
                break;
            case 5:
                printf("Saindo do sistema...\n");
                break;
            default:
                printf("Opcao invalida.\n");
        }
    } while(opcao != 5);
    return 0;
}