#include <stdio.h>

int main()
{
    // declaracoes de variaveis
    float notas[3];
    float media = 0.0;
    float frequencia;

    // leitura e validacao das notas
    for(int i = 0; i < 3; i++)
    {
        printf("Digite a nota %d: ", i + 1);
        while (scanf("%f", &notas[i]) != 1 || notas[i] < 0.0 || notas[i] > 10.0)
        {
            printf("Nota invalida, digite novamente: ");
            while (getchar() != '\n');
        }
        media += notas[i];
    }

    // leitura e validacao da frequencia
    printf("Digite a frequencia (em porcentagem): ");
    while (scanf("%f", &frequencia) != 1 || frequencia < 0.0 || frequencia > 100.0)
    {
        printf("Frequencia invalida, digite novamente: ");
        while (getchar() != '\n');
    }

    // calculo da media
    media /= 3.0;

    // determinacao do conceito
    char conceito;
    if (media >= 9.0 && media <= 10.0) {
        conceito = 'A';
    } else if (media >= 7.0 && media < 9.0) {
        conceito = 'B';
    } else if (media >= 5.0 && media < 7.0) {
        conceito = 'C';
    } else {
        conceito = 'D';
    }

    // verificacao de aprovacao
    if (media >= 5.0 && frequencia >= 75.0) {
        printf("Aluno aprovado.\n");
    } else if (media < 5.0 && frequencia >= 75.0) {
        printf("Aluno reprovado por nota.\n");
    } else if (media >= 5.0 && frequencia < 75.0) {
        printf("Aluno reprovado por frequencia.\n");
    } else if (media < 5.0 && frequencia < 75.0) {
        printf("Aluno reprovado por nota e frequencia.\n");
    }

    // exibicao dos resultados
    printf("Media: %.2f\n", media);
    printf("Conceito: %c\n", conceito);

    return 0;
}
